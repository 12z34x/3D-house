﻿using UnityEngine;
using System.Collections;

public class cubee : MonoBehaviour
{
    public float speedy=0;
    public float speedx = 0;
    public float speedz = 0;

    // Use this for initialization
    void Start()
    {

    }
    public void zButton()
    {
        speedx = 0;
        speedz = 500;
        speedy = 0;
    }
    public void xButton()
    {
        speedz = 0;
        speedx = 500;
        speedy = 0;
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Y))
        {
            speedy = 500;
            gameObject.GetComponent<Renderer>().material.color = Color.yellow;
        }
        gameObject.transform.Rotate(Vector3.down * speedy);
        gameObject.transform.Rotate(Vector3.left * speedx);
        gameObject.transform.Rotate(Vector3.back * speedz);
    }
}
