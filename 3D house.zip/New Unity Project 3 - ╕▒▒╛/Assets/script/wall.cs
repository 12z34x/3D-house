﻿using UnityEngine;
using System.Collections;

public class wall : MonoBehaviour {
    public GameObject body;
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
      
	}
 void OnMouseDown()
    {
        gameObject.GetComponent<Rigidbody>().AddForce(Vector3.forward * 1000);

    }
}
